﻿//document.querySelector("h1").innerHTML = "Alamgir kabir"
$("h1").text("Nurjahan Medical Center")